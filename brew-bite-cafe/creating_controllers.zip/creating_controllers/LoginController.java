public class LoginController {
    public void handleLogin() {}
}
