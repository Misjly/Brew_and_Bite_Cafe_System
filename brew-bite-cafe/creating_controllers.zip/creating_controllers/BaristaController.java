public class BaristaController implements Observer {

    private OrderModel orderModel;

    public BaristaController() {}

    @Override
    public void update() {
        // refresh barista queue display
    }

    public void handleStatusChange(){}
    public void handleCompleteOrder(){}
}
