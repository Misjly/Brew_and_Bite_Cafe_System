public class LandingController {
    public void handleCustomer() {}
    public void handleEmployeeLogin() {}
}
