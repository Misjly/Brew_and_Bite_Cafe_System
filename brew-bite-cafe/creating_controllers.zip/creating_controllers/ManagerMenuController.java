public class ManagerMenuController implements Observer {

    public ManagerMenuController(){}

    @Override
    public void update() {
        // refresh menu view
    }

    public void handleAdd(){}
    public void handleEdit(){}
    public void handleRemove(){}
}
