public class ManagerInventoryController implements Observer {

    private InventoryModel inventoryModel;

    public ManagerInventoryController(){}

    @Override
    public void update() {
        // refresh table
    }

    public void handleRestock(){}
}
